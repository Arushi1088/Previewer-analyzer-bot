
# Analyzer Bot Scaffold (FastAPI)

This scaffold lets you upload a **video** + **config text** and get:
- keyframe extraction
- LLM-based bug analysis (uses your `backend/data/mobile_prompt_blueprint.md` as rules)
- HTML report with frames, steps, bugs
- Eval vs built-in golden list `backend/data/golden_bugs.csv`

## Quickstart

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8080
```

Open http://localhost:8080 to upload.

### LLM
Set `OPENAI_API_KEY` or implement your provider in `backend/core/llm.py`. Without a key, a stub response is returned so you can test the pipeline.

### Golden List
Edit `backend/data/golden_bugs.csv`. This is used automatically for eval — no upload needed.

### Uses your mobile pack
The following files were copied into `backend/data/`:
- `mobile_prompt_blueprint.md`
- `rulebook.json`
- `mobile_excel_matrix.json`
- `mobile_excel_matrix.csv`
- `mobile_final_master_matrix.csv`
- `README_mobile_pack.md`
You can reference them for future prompt improvements or scoring logic.
```
