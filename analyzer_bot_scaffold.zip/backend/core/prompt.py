
import json, os, textwrap

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def load_blueprint():
    bp_path = os.path.join(DATA_DIR, "mobile_prompt_blueprint.md")
    try:
        with open(bp_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

def build_prompt(cfg, frames):
    blueprint = load_blueprint()
    frames_summary = [
        {"index": f["index"], "ts_ms": f["ts_ms"], "rel_path": f["path"].split("static/")[-1]}
        for f in frames
    ]
    user_payload = {
        "scenario": {
            "id": cfg.scenario_id,
            "source_apps": cfg.source_apps,
            "file_size_bucket": cfg.file_size_bucket,
            "protection_level": cfg.protection_level,
            "file_type": cfg.file_type,
            "notes": cfg.notes or ""
        },
        "frames": frames_summary,
        "instructions": {
            "return_format": {
                "bugs":[{"id":"","title":"","description":"","severity":"","category":"","evidence_frames":[],"suggestions":""}],
                "steps":[{"step_no":0,"summary":"","frames":[]}],
                "assumptions":"",
                "metadata":{"version":"v0"}
            }
        }
    }
    system = "You are a meticulous QA triage assistant for Outlook→Excel Previewer→Excel Desktop flows. Output STRICT JSON only."
    # Prepend blueprint (rules/criteria) if available
    if blueprint:
        system = system + "\n\n" + blueprint[:6000]  # cap to avoid overlong system prompt
    return {
        "system": system,
        "user": json.dumps(user_payload, ensure_ascii=False)
    }
