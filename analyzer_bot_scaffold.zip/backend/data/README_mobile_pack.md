
# Mobile Video Analysis Pack (Matrix + Prompt)

### Files
- `mobile_excel_matrix.csv` — long-form scenario matrix
- `mobile_excel_matrix.json` — same in JSON with symbols
- `mobile_prompt_blueprint.md` — guardrail prompt (IF/THEN rules)
- Symbols used:
{
  "PREVIEWER_OK": "PREVIEWER_OK",
  "PREVIEWER_WARN": "PREVIEWER_WARN",
  "PREVIEWER_FAIL": "PREVIEWER_FAIL",
  "HANDOFF_EXCEL": "HANDOFF_EXCEL",
  "HANDOFF_M365": "HANDOFF_M365",
  "HANDOFF_BROWSER": "HANDOFF_BROWSER",
  "HANDOFF_STORE": "HANDOFF_STORE",
  "HANDOFF_NONE": "HANDOFF_NONE",
  "OPEN_SUCCESS": "OPEN_SUCCESS",
  "OPEN_ERROR": "OPEN_ERROR",
  "REDIRECT_DESKTOP_ALLOWED": "REDIRECT_DESKTOP_ALLOWED",
  "REDIRECT_DESKTOP_FORBIDDEN": "REDIRECT_DESKTOP_FORBIDDEN",
  "CTA_INSTALL_EXCEL": "CTA_INSTALL_EXCEL",
  "CTA_OPEN_EXCEL": "CTA_OPEN_EXCEL",
  "CTA_SWITCH_ACCOUNT": "CTA_SWITCH_ACCOUNT",
  "CTA_TRY_AGAIN": "CTA_TRY_AGAIN",
  "CTA_OPEN_BROWSER": "CTA_OPEN_BROWSER"
}

### How to integrate
1. Place files into your repo:
   - `real_data/mobile_excel_matrix.csv`
   - `real_data/mobile_excel_matrix.json`
   - `prompts/mobile_prompt_blueprint.md`
2. In your analyzer, load the JSON, match a row using your UI inputs (device, accounts, apps installed, protection, size…). Pass:
   - `scenario_config` (your inputs)
   - `expected_slice` (from the matched matrix row)
   - Ordered frames and OCR strings
   - The prompt blueprint text
3. Parse the STRICT JSON result and render Functional vs Craft bugs.

### Notes
- These are guardrails; the model must still ground all findings on visible evidence.
- Avoid hardcoding outcomes; always compare observed vs expected with the provided symbols.
